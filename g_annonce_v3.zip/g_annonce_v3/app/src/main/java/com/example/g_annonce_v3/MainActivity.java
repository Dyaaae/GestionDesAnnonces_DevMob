package com.example.g_annonce_v3;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    DBConnect cn;
    TextInputEditText t1, t2;
    Button bLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        cn = new DBConnect(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bLogin = findViewById(R.id.bLogin);
        t1 = findViewById(R.id.UserName);
        t2 = findViewById(R.id.pwd);


        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username = t1.getText().toString();
                String password = t2.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if user exists
                if (cn.userExists(username, password)) {
                    // User exists, navigate to HomeActivity
                    startActivity(new Intent(MainActivity.this, HomeActivity.class));
                }
                if (username.equals("admin") && password.equals("admin")) {
                        // User is admin
                startActivity(new Intent(MainActivity.this, AccueilActivity.class));
                } else {
                    Toast.makeText(MainActivity.this, "Nom d'utilisateur ou mot de passe invalide", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void register (View view){
        startActivity(new Intent(MainActivity.this, RegisterActivity.class));
    }
}