package com.example.g_annonce_v3;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class RegisterActivity extends AppCompatActivity {
    DBConnect cn;
    Button bRegister;
    TextInputEditText t1,t2,t3,t4;
    User user = new User(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        cn = new DBConnect(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        bRegister =findViewById(R.id.bRegister);
        t1=findViewById(R.id.UserNameR);
        t2=findViewById(R.id.emailR);
        t3=findViewById(R.id.phoneNumberR);
        t4=findViewById(R.id.pwdR);

        bRegister.setOnClickListener(new View.OnClickListener() {

            String userName = t1.getText().toString();
            String email = t2.getText().toString();
            String phoneNumber = t3.getText().toString();
            String password = t4.getText().toString();
            @Override
            public void onClick(View view) {
                if (t1.getText().toString().isEmpty() || t2.getText().toString().isEmpty() || t3.getText().toString().isEmpty() || t4.getText().toString().isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
                } else if (cn.userEmailExists(userName, email)) {
                    // L'utilisateur ou l'email existe déjà, afficher un message d'erreur
                    Toast.makeText(RegisterActivity.this, "Le nom d'utilisateur ou l'e-mail existe déjà", Toast.LENGTH_SHORT).show();
                }
                else{
                    user.insertdt(t1.getText().toString(), t2.getText().toString(), t3.getText().toString(), t4.getText().toString());
                    t1.setText(null);
                    t2.setText(null);
                    t3.setText(null);
                    t4.setText(null);
                }
                Toast.makeText(RegisterActivity.this, "Utilisateur enregistré avec succès", Toast.LENGTH_SHORT).show();
            }

        });


    }

    public void login(View view){
        startActivity(new Intent(RegisterActivity.this, MainActivity.class));

    }
}