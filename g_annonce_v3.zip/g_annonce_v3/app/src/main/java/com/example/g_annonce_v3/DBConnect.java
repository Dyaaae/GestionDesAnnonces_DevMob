package com.example.g_annonce_v3;

import static androidx.constraintlayout.widget.ConstraintLayoutStates.TAG;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class DBConnect extends SQLiteOpenHelper {
    public DBConnect(@Nullable Context context) {
        super(context, "GestionAnnonces_v2", null, 1);
    }



    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("create table annonce(code integer primary key, title varchar(25), description varchar(25), price varchar(6), contact varchar(10),email varchar(20))");
        db.execSQL("create table user(code integer primary key AUTOINCREMENT, userName varchar(25),  email varchar(25), phoneNumber varchar(10), pwd varchar(25))");
        Log.d(TAG, "onCreate: Created table user");

    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int i, int i1) {

        db.execSQL("drop table annonce");
        db.execSQL("drop table user");
        onCreate(db);
    }

    public boolean userExists(String userName, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE userName = ? AND pwd = ?", new String[]{userName, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }


    public boolean userEmailExists(String userName, String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE userName = ? OR email = ?", new String[]{userName, email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}
