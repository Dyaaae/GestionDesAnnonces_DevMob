package com.example.g_annonce_v3;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {


    ListView listview;
    SearchView searchview;
    Annonce annonce= new Annonce(this);;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        listview = findViewById(R.id.listview);
        searchview = findViewById(R.id.search);


        // Récupérer les données depuis la base de données
        Cursor cursor = annonce.data();

        // Vérifier si le curseur contient des données
        if (cursor != null && cursor.getCount() > 0) {
            // Définir un adaptateur pour la ListView ou afficher les données dans d'autres vues
            SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                    this,
                    android.R.layout.simple_list_item_2,
                    cursor,
                    new String[]{"title", "price"},
                    new int[]{android.R.id.text1, android.R.id.text2}
            );

            // Associer l'adaptateur à la ListView
            listview.setAdapter(adapter);
        } else {
            Toast.makeText(this, "Aucune donnée disponible", Toast.LENGTH_SHORT).show();
        }

        searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Appeler la méthode search avec le texte saisi par l'utilisateur
                Cursor cursor = annonce.search(query);

                // Afficher les résultats de la recherche dans la ListView
                if (cursor != null && cursor.getCount() > 0) {
                    // Définir un adaptateur pour la ListView ou afficher les données dans d'autres vues
                    SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                            HomeActivity.this,
                            android.R.layout.simple_list_item_2,
                            cursor,
                            new String[]{"title", "price"},
                            new int[]{android.R.id.text1, android.R.id.text2}
                    );
                    listview.setAdapter(adapter);
                } else {

                    Toast.makeText(HomeActivity.this, "Aucun résultat trouvé", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Ne rien faire ici, car nous voulons déclencher la  recherche uniquement lors de la soumission du texte
                return false;
            }
        });

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Obtenez les données associées à l'élément sélectionné
                Cursor cursor = (Cursor) parent.getItemAtPosition(position);
                String title = cursor.getString(cursor.getColumnIndex("title"));
                String description = cursor.getString(cursor.getColumnIndex("description"));
                String price = cursor.getString(cursor.getColumnIndex("price"));
                String contact = cursor.getString(cursor.getColumnIndex("contact"));
                String email = cursor.getString(cursor.getColumnIndex("email"));

                // Créez un Intent pour démarrer une nouvelle activité et transmettre les données
                Intent intent = new Intent(HomeActivity.this, DetailActivity.class);
                intent.putExtra("title", title);
                intent.putExtra("description", description);
                intent.putExtra("price", price);
                intent.putExtra("contact", contact);
                intent.putExtra("email", email);
                startActivity(intent);
            }
        });
    }}