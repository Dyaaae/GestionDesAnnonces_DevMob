package com.example.g_annonce_v3;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Annonce {
    DBConnect cn;
    //   public static ArrayList<Annonce> annonceArrayList = new ArrayList<>();


    public Annonce(Context context) {
        cn = new DBConnect(context);
    }

    public void insertdt(int code, String title, String descp, String price, String contact, String email) {
        SQLiteDatabase db = cn.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("code", code);
        values.put("title", title);
        values.put("description", descp);
        values.put("price", price);
        values.put("contact", contact);
        values.put("email", email);
        db.insert("annonce", null, values);
    }

    public void delete(Integer code) {
        SQLiteDatabase db = cn.getWritableDatabase();
        String[] s = new String[]{String.valueOf(code)};
        db.delete("annonce", "code=?", s);
    }

    public void update(Integer code, String title, String descp, String price, String contact, String email) {
        SQLiteDatabase db = cn.getWritableDatabase();
        ContentValues contentValue = new ContentValues();
        contentValue.put("title", title);
        contentValue.put("description", descp);
        contentValue.put("price", price);
        contentValue.put("contact", contact);
        contentValue.put("email", email);
        String[] rsl = new String[]{String.valueOf(code)};
        db.update("annonce", contentValue, "code=?", rsl);
    }

    public Cursor data() {
        SQLiteDatabase db = cn.getReadableDatabase();
        return db.rawQuery("select code as _id,title,description,price,contact,email from annonce", null);
    }

    public Cursor search(String text) {
        SQLiteDatabase db = cn.getReadableDatabase();

        String query = "SELECT code AS _id, title, description, price, contact FROM annonce WHERE title LIKE '%" + text + "%'";
        return db.rawQuery(query, null);

    }

}








