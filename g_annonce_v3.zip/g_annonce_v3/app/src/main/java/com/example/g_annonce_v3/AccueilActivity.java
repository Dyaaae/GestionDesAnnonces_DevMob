package com.example.g_annonce_v3;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AccueilActivity extends AppCompatActivity {
    ListView lv;
    EditText t0,t1,t2,t3,t4,t5;
    Button b1,b2,b3;

    Annonce annonce = new Annonce(this);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil);
        lv =findViewById(R.id.annonceListView);
        b1 =findViewById(R.id.bAdd);
        b2 =findViewById(R.id.bUpdate);
        b3 =findViewById(R.id.bDelete);

        t0 = findViewById(R.id.code);
        t1 = findViewById(R.id.title);
        t2 = findViewById(R.id.desc);
        t3 = findViewById(R.id.price);
        t4 = findViewById(R.id.contact);
        t5 = findViewById(R.id.email);

        actualiser();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (t0.getText().toString().isEmpty() || t1.getText().toString().isEmpty() || t2.getText().toString().isEmpty() || t3.getText().toString().isEmpty() || t4.getText().toString().isEmpty() || t5.getText().toString().isEmpty()) {
                    Toast.makeText(AccueilActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
                } else {
                    annonce.insertdt(Integer.parseInt(t0.getText().toString()),t1.getText().toString(),t2.getText().toString(),t3.getText().toString(),t4.getText().toString(),t5.getText().toString());
                    actualiser();
                    t0.setText(null);
                    t1.setText(null);
                    t2.setText(null);
                    t3.setText(null);
                    t4.setText(null);
                    t5.setText(null);
                }}
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (t0.getText().toString().isEmpty()) {
                    Toast.makeText(AccueilActivity.this, "Veuillez saisir un code", Toast.LENGTH_SHORT).show();
                } else {

                    annonce.update(Integer.parseInt(t0.getText().toString()),t1.getText().toString(),t2.getText().toString(),t3.getText().toString(),t4.getText().toString(),t5.getText().toString());
                    actualiser();
                    t0.setText(null);
                    t1.setText(null);
                    t2.setText(null);
                    t3.setText(null);
                    t4.setText(null);
                    t5.setText(null);
                }}
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (t0.getText().toString().isEmpty()) {
                    Toast.makeText(AccueilActivity.this, "Veuillez saisir un code", Toast.LENGTH_SHORT).show();
                } else {
                    annonce.delete(Integer.parseInt(t0.getText().toString()));
                    actualiser();
                    t1.setText("");
                }}
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Obtenez le curseur associé à l'élément sélectionné
                Cursor cursor = (Cursor) parent.getItemAtPosition(position);
                if (cursor != null && cursor.moveToPosition(position)) {
                    // Récupérez les données de la colonne souhaitée
                    String title = cursor.getString(cursor.getColumnIndex("title"));
                    String description = cursor.getString(cursor.getColumnIndex("description"));
                    String price = cursor.getString(cursor.getColumnIndex("price"));
                    String contact = cursor.getString(cursor.getColumnIndex("contact"));
                    String email = cursor.getString(cursor.getColumnIndex("email"));

                    // Créez un Intent pour démarrer une nouvelle activité et transmettre les données
                    Intent intent = new Intent(AccueilActivity.this, DetailActivity.class);
                    intent.putExtra("title", title);
                    intent.putExtra("description", description);
                    intent.putExtra("price", price);
                    intent.putExtra("contact", contact);
                    intent.putExtra("email", email);
                    startActivity(intent);
                } else {
                    Toast.makeText(AccueilActivity.this, "Impossible de récupérer les données de l'annonce", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void actualiser() {
        SimpleCursorAdapter adap = new SimpleCursorAdapter(getApplicationContext(),
                android.R.layout.simple_list_item_2,
                annonce.data(),
                new String[]{"title","price"},
                new int[]{android.R.id.text1,android.R.id.text2}
        );
        lv.setAdapter(adap);
    }
    public void home(View view){
        startActivity(new Intent(AccueilActivity.this, HomeActivity.class));

    }

}
