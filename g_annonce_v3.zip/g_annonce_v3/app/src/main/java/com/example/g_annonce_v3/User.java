package com.example.g_annonce_v3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class User {

    DBConnect cn;

    public User(Context context) {
        cn= new DBConnect(context);
    }

    public void insertdt(String userName, String email, String phoneNumber, String pwd){
        SQLiteDatabase db = cn.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("userName",userName);
        values.put("email",email);
        values.put("phoneNumber",phoneNumber);
        values.put("pwd",pwd);
        db.insert("user",null,values);
    }

    public void delete(Integer code){
        SQLiteDatabase db = cn.getWritableDatabase();
        String[] s = new String []{String.valueOf(code)};
        db.delete("user","code=?",s);
    }


}
