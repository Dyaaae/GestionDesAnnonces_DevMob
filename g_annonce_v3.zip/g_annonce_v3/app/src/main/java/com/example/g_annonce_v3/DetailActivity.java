package com.example.g_annonce_v3;

import static android.Manifest.permission.CALL_PHONE;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.w3c.dom.Text;

public class DetailActivity extends AppCompatActivity {
    TextView contactTextView, emailTextView;
    Button bAppel;
    Button bMessage;
    Button bEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Récupérer les données transmises depuis l'activité précédente
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String title = extras.getString("title");
            String description = extras.getString("description");
            String price = extras.getString("price");
            String contact = extras.getString("contact");
            String email = extras.getString("email");

            // Afficher les données dans les TextViews appropriés
            TextView titleTextView = findViewById(R.id.tv1);
            TextView descriptionTextView = findViewById(R.id.tv2);
            TextView priceTextView = findViewById(R.id.tv3);
            contactTextView = findViewById(R.id.tv4);
            emailTextView =findViewById(R.id.tv5);

            bAppel = findViewById(R.id.bA);
            bMessage = findViewById(R.id.bMessage);
            bEmail = findViewById(R.id.bEmail);

            titleTextView.setText(title);
            descriptionTextView.setText(description);
            priceTextView.setText(price);
            contactTextView.setText(contact);
            emailTextView.setText(email);
        }
        ActivityCompat.requestPermissions(this,new String []{CALL_PHONE},PackageManager.PERMISSION_GRANTED);

        bAppel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkCallingOrSelfPermission(CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
                    return;
                }
                startActivity(new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", contactTextView.getText().toString(), null)));


            }

        });

        bEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailTextView.getText().toString();
                if (!email.isEmpty()) {
                    Uri emailUri = Uri.parse("mailto:" + email);
                    Intent emailIntent = new Intent(Intent.ACTION_SENDTO, emailUri);
                    startActivity(Intent.createChooser(emailIntent, "Envoyer un e-mail"));
                } else {
                    Toast.makeText(DetailActivity.this, "Aucune adresse e-mail disponible", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = contactTextView.getText().toString();
                String message = "Votre message ici"; // Modifiez cela selon votre besoin

                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("sms:" + phoneNumber));
                intent.putExtra("sms_body", message);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });

        }}

